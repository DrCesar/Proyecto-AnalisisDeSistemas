package com.example.user.pago;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class CardInformation extends AppCompatActivity {

    private String[] arraySpinner1, arraySpinnerMonth, arraySpinnerYear;
    Spinner s;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_information);

        this.arraySpinner1 = new String[] {
                "Visa", "MasterCard", "American Express"
        };
        s = (Spinner) findViewById(R.id.spinner1);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, arraySpinner1);
        s.setAdapter(adapter1);

        this.arraySpinnerMonth = new String[] {
                "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"
        };
        s = (Spinner) findViewById(R.id.spinner3);
        ArrayAdapter<String> adapterMonth = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arraySpinnerMonth);
        s.setAdapter(adapterMonth);

        this.arraySpinnerYear = new String[] {
                "2017", "2018", "2019", "2020", "2021", "2022"
        };
        s = (Spinner) findViewById(R.id.spinner4);
        ArrayAdapter<String> adapterYear = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arraySpinnerYear);
        s.setAdapter(adapterYear);
    }

    public void continueOrder(View view) {
        Intent intent = new Intent(this, PaidOrder.class);
        startActivity(intent);
    }
}
