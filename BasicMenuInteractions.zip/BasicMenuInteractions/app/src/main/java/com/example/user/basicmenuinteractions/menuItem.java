package com.example.user.basicmenuinteractions;

import android.os.Parcel;
import android.os.Parcelable;

public class menuItem implements Parcelable {
    private String name;
    private int price;

    public menuItem (String name, int price){
        this.name = name;
        this.price = price;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getName() {
        return this.name;
    }

    public int getPrice() {
        return this.price;
    }

    // Parcelling part
    public menuItem(Parcel in){
        String[] data = new String[2];

        in.readStringArray(data);
        // the order needs to be the same as in writeToParcel() method
        this.name = data[0];
        this.price = Integer.valueOf(data[1]);
    }

    public int describeContents(){
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeStringArray(new String[] {this.name,
                String.valueOf(this.price)});
    }
    public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
        public menuItem createFromParcel(Parcel in) {
            return new menuItem(in);
        }

        public menuItem[] newArray(int size) {
            return new menuItem[size];
        }
    };
}
