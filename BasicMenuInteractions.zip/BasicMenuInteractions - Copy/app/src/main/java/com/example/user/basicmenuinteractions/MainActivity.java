package com.example.user.basicmenuinteractions;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;

import java.util.ArrayList;

import static com.example.user.basicmenuinteractions.R.id.checkBox;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void addToCart(View view){
        Intent intent = new Intent(this, Cart.class);
        ArrayList<menuItem> cart = new ArrayList<>();
        menuItem temp;

        if (((CheckBox)findViewById(R.id.checkBox)).isChecked()) {
            temp = new menuItem("Pizza grande", 100);
            cart.add(temp);
        }
        if (((CheckBox)findViewById(R.id.checkBox2)).isChecked()) {
            temp = new menuItem("Pizza mediana", 120);
            cart.add(temp);
        }
        if (((CheckBox)findViewById(R.id.checkBox3)).isChecked()) {
            temp = new menuItem("Pizza personal", 60);
            cart.add(temp);
        }
        if (((CheckBox)findViewById(R.id.checkBox4)).isChecked()) {
            temp = new menuItem("Pollo frito", 50);
            cart.add(temp);
        }
        if (((CheckBox)findViewById(R.id.checkBox5)).isChecked()) {
            temp = new menuItem("Alitas en barbacoa", 75);
            cart.add(temp);
        }
        if (((CheckBox)findViewById(R.id.checkBox6)).isChecked()) {
            temp = new menuItem("Papas fritas", 15);
            cart.add(temp);
        }

        intent.putParcelableArrayListExtra("list", cart);
        startActivity(intent);
    }
}
