package com.example.user.basicmenuinteractions;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;

public class Cart extends AppCompatActivity {

    private int total = 0;
    private ArrayList<CheckBox> checkboxes;
    private ArrayList<menuItem> cart
    private  FirebaseAuth auth = FirebaseAuth.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (auth.getCurrentUser() != null) {
            startActivity(SignedInActivity.createIntent(this, null));
            finish();
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        cart = getIntent().getParcelableArrayListExtra("list");

        checkboxes = new ArrayList<>();
        checkboxes.add((CheckBox)findViewById(R.id.checkBox));
        checkboxes.add((CheckBox)findViewById(R.id.checkBox2));
        checkboxes.add((CheckBox)findViewById(R.id.checkBox3));
        checkboxes.add((CheckBox)findViewById(R.id.checkBox4));
        checkboxes.add((CheckBox)findViewById(R.id.checkBox5));
        checkboxes.add((CheckBox)findViewById(R.id.checkBox6));

        updateCart();
    }

    private void updateCart() {

        for (int i = 0; i < 6; i++) {
            checkboxes.get(i).setVisibility(View.INVISIBLE);
            checkboxes.get(i).setChecked(false);
        }

        total = 0;
        for (int i = 0; i < cart.size(); i++) {
            checkboxes.get(i).setVisibility(View.VISIBLE);
            checkboxes.get(i).setText(cart.get(i).getName() + " - Q." + String.valueOf(cart.get(i).getPrice()) + ".00");
            total += cart.get(i).getPrice();
        }

        TextView temp =  (TextView)findViewById(R.id.textView3);
        temp.setText("Total: Q." + String.valueOf(total) + ".00");
    }

    public void deleteFromMenu(View view) {
        for (int i = cart.size()-1; i >= 0; i--) {
            if (checkboxes.get(i).isChecked())
                cart.remove(i);
        }
        updateCart();
    }

    public void checkItem(View view) {
        startActivityForResult(
                AuthUI.getInstance().createItemIntentBuilder()
                        .build(),
                RC_CHECK_ITEM);
    }

}
